# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function receives a request to export data from an AWS DynamoDB table to a CSV file,
#              and then uploads the CSV file to Google Cloud Storage (GCS).

import os
import boto3
import csv
import json
from google.cloud import storage

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    # Extract the request body as a JSON string from the event
    body_json = event.get('body')
    event = json.loads(body_json)
    
    # Configuration - Extract necessary parameters from the event
    dynamodb_table_name = event['table']
    gcs_bucket_name = event['bucket']
    gcs_file_name = event['filename']

    # Initialize AWS DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(dynamodb_table_name)

    # Get data from DynamoDB table
    response = table.scan()
    items = response['Items']

    # Convert data to CSV format
    csv_data = []
    if items:
        csv_data.append(list(items[0].keys()))  # Header row with column names
        for item in items:
            csv_data.append(list(item.values()))  # Data rows

    # Create CSV file
    csv_file_path = "/tmp/" + gcs_file_name
    with open(csv_file_path, mode='w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerows(csv_data)

    # Initialize Google Cloud Storage client
    # Please make sure to replace "serverlesssummer2023-6eb6a8916018.json" with the actual path to your GCP service account credentials
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "serverlesssummer2023-6eb6a8916018.json"
    gcs_client = storage.Client()

    # Check if the file already exists in GCS and delete it if exists
    bucket = gcs_client.get_bucket(gcs_bucket_name)
    blob = bucket.blob(gcs_file_name)

    if blob.exists():
        blob.delete()

    # Upload CSV file to Google Cloud Storage
    blob.upload_from_filename(csv_file_path)

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
        },
        'body': json.dumps('Data uploaded to Google Cloud Storage successfully.')
    }

# [Additional functions and utility code can be added here if needed]
