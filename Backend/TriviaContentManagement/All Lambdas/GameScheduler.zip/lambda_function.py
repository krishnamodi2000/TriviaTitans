# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function receives a request to schedule a trivia game and sends game details to an SNS topic
#              for the game scheduler and the players. It also handles validation and error cases.

import json
import boto3
import datetime

# Create a DynamoDB resource, SQS client, and SNS client
dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')
sns = boto3.client('sns')

# Function to retrieve game details from the DynamoDB table based on the game_id
def get_game_details(game_id):
    table = dynamodb.Table('gameCreationDb')
    response = table.get_item(Key={'game_id': game_id})
    return response.get('Item')

# Function to schedule a game based on the provided game_id and scheduled_time
def schedule_game(game_id, scheduled_time):
    game_details = get_game_details(game_id)
    if not game_details:
        message = f"Game with ID {game_id} not found."
        return {
            'statusCode': 404,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps(message)
        }

    category = game_details['category']
    difficulty_level = game_details['difficulty_level']
    time_frame_minutes = int(game_details['time_frame_minutes'])
    questions = game_details['questions']

    # Make current_time offset-aware with UTC timezone
    current_time = datetime.datetime.now(datetime.timezone.utc)
    print(current_time)

    # Make scheduled_time offset-aware with UTC timezone (assuming scheduled_time is in UTC)
    scheduled_time = scheduled_time.replace(tzinfo=datetime.timezone.utc)
    formatted_current_time = scheduled_time.strftime('%Y-%m-%dT%H:%M:%SZ')

    # Calculate the time remaining until the scheduled time
    time_remaining = (scheduled_time - current_time).total_seconds()

    if time_remaining <= 0:
        message = "The specified time is in the past. Cannot schedule the game."
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps(message)
        }

    delay_seconds = int(time_remaining) if time_remaining <= 900 else 0

    # Send the game details to the SNS Topics for the game scheduler and the players
    topics = sns.list_topics()
    topic_arn_scheduler = next((topic['TopicArn'] for topic in topics['Topics'] if 'GameScheduled' in topic['TopicArn']), None)
    topic_arn_players = next((topic['TopicArn'] for topic in topics['Topics'] if 'TriviaGameUpdatesTopic' in topic['TopicArn']), None)

    message_to_scheduler = {
        'game_id': game_id,
        'category': category,
        'difficulty_level': difficulty_level,
        'time_frame_minutes': time_frame_minutes,
        'scheduled_time': str(formatted_current_time),
        'questions': questions,
        'message': 'Game has been scheduled and questions are ready!'
    }

    message_to_players = f"Game has been scheduled for {str(scheduled_time)}. Category: {category}, Difficulty: {difficulty_level}, Time Frame: {time_frame_minutes} minutes. Be ready with your team soon!"

    response_to_scheduler = sns.publish(TopicArn=topic_arn_scheduler, Message=json.dumps(message_to_scheduler))
    print("Message published to SNS topic successfully!", message_to_scheduler)
    print("Message ID:", response_to_scheduler['MessageId'])

    response_to_player = sns.publish(TopicArn=topic_arn_players, Message=message_to_players)
    print("Message published to SNS topic successfully!", message_to_players)
    print("Message ID:", response_to_player['MessageId'])

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
        },
        'body': json.dumps(message_to_scheduler)
    }

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    # Extract the request body as a JSON string from the event
    body_json = event.get('body')
    # event = json.loads(body_json)
    
    # # Extract the game_id and scheduled_time from the event
    # game_id = event.get('game_id')
    # scheduled_time_str = event.get('scheduled_time')
    game_id = event['game_id']
    scheduled_time_str = event['scheduled_time']
    
    # Define the date format used for parsing the scheduled_time string
    date_format = "%Y-%m-%dT%H:%M:%S.%fZ"
    
    # Convert the scheduled_time string to a datetime object
    scheduled_time = datetime.datetime.strptime(scheduled_time_str, date_format)
    
    # Retrieve game details and schedule the game based on the provided information
    game_details = get_game_details(game_id)
    response_payload = schedule_game(game_id, scheduled_time)

    # Return the response payload as the Lambda response
    return response_payload

# [Additional functions and utility code can be added here if needed]
