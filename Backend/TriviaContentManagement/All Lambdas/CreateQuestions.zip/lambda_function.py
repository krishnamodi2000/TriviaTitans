# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function receives a question data as input, generates a unique ID for the question,
#              performs automated tagging on the question and explanation, and stores the question data in a DynamoDB table.

import json
import boto3
import http.client
import uuid

# Create a DynamoDB resource and specify the table to interact with
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('questionsdb')

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    try:
        # Extract the request body as a JSON string from the event
        body_json = event.get('body')
        event = json.loads(body_json)

        # Generate a unique question ID using UUID
        question_id = str(uuid.uuid4())

        # Perform automated tagging on the question using the 'automated_tags' function
        tags = automated_tags(event)

        # Prepare the question data to be stored in DynamoDB
        question_data = {
            'question_id': question_id,
            'question': event['question'],
            'options': event['options'],
            'answer': event['answer'],
            'difficulty_level': event['difficulty_level'].lower(),
            'category': event['category'],
            'hints': event['hints'],
            'explanation': event['explanation'],
            'tags': tags
        }

        # Store the question data in DynamoDB using the 'put_item' method
        table.put_item(Item=question_data)

        # Prepare and return a successful response with status code 201
        return {
            'statusCode': 201,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps({'message': 'Question added successfully.'})
        }
    except Exception as e:
        # If there's an exception, return an error response with status code 500
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps({'error': str(e)})  # Convert the error message to a JSON string
        }

# Function to perform automated tagging on the question using an external API
def automated_tags(request):
    automated_tags_url = "us-east1-serverlesssummer2023.cloudfunctions.net"
    payload = {
        "question_text": request['question'],
        "explanation_text": request['explanation']
    }
    headers = {
        "Content-Type": "application/json"
    }

    # Make a POST request to the automated tagging API endpoint
    conn = http.client.HTTPSConnection(automated_tags_url)
    conn.request("POST", "/automated_tagging", body=json.dumps(payload), headers=headers)

    response = conn.getresponse()
    if response.status == 200:
        result = json.loads(response.read().decode())
        tags = result['tags']
        return tags
    else:
        # Handle the response error if needed
        return []

# [Additional functions and utility code can be added here if needed]
