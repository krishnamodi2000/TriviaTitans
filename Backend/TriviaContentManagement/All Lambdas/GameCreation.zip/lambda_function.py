# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function receives a request to create a trivia game, generates random questions from a
#              DynamoDB table based on the specified category and difficulty level, and stores the game details in
#              another DynamoDB table representing game creations.

import json
import boto3
import random
import datetime

# Create a DynamoDB resource and SQS client
dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')

# Function to retrieve questions from DynamoDB based on category and difficulty level
def get_questions(category, difficulty_level):
    print(category, difficulty_level)
    table = dynamodb.Table('questionsdb')
    response = table.scan(
        FilterExpression="category = :category and difficulty_level = :difficulty_level",
        ExpressionAttributeValues={":category": category, ":difficulty_level": difficulty_level}
    )
    print(response)
    return response['Items']

# Function to calculate the maximum number of questions allowed in the game based on time frame and question time
def calculate_max_questions(time_frame_minutes, question_time):
    time_frame_seconds = time_frame_minutes * 60
    return time_frame_seconds // question_time

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    # Extract the request body as a JSON string from the event
    body_json = event.get('body')
    event = json.loads(body_json)

    # Extract the category, difficulty level, and time frame from the event
    category = event.get('category')
    difficulty_level = event.get('difficulty_level')
    time_frame_minutes = event.get('time_frame', 10)  # Default time frame is 10 minutes
    
    print(category, difficulty_level, time_frame_minutes)

    # Retrieve questions from DynamoDB based on the category and difficulty level
    questions = get_questions(category, difficulty_level)
    
    print(questions)

    # Adjust the game length based on the selected difficulty level
    if difficulty_level == 'easy':
        question_time = 20
        min_game_length = 5
        max_game_length = 10
    elif difficulty_level == 'medium':
        question_time = 40
        min_game_length = 15
        max_game_length = 20
    else:  # 'hard'
        question_time = 60
        min_game_length = 25
        max_game_length = 30

    # Calculate the maximum number of questions allowed in the game based on time frame and question time
    max_questions = calculate_max_questions(int(time_frame_minutes), int(question_time))
    print(max_questions)
    
    # Select random questions from the retrieved questions list
    selected_questions = random.sample(questions, min(len(questions), max_questions))
    print(selected_questions)

    if len(selected_questions) < 5:
        # Return a response with status code 400 if not enough questions are available
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': f'Not enough {difficulty_level} questions for category {category}'
        }

    # Create a game ID (use a timestamp for simplicity)
    game_id = str(datetime.datetime.now().timestamp())

    # Store the game details in the 'TriviaGames' table
    games_table = dynamodb.Table('gameCreationDb')
    games_table.put_item(Item={
        'game_id': game_id,
        'category': category,
        'difficulty_level': difficulty_level,
        'time_frame_minutes': time_frame_minutes,
        'questions': selected_questions
    })
    
    # Prepare and return a successful response with status code 200
    response = {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
            'Access-Control-Allow-Origin': '*',
            'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
        },
        'body': json.dumps({
            'game_id': game_id,
            'category': category,
            'difficulty_level': difficulty_level,
            'time_frame_minutes': time_frame_minutes,
            'questions': selected_questions
        })
    }

    return response

# [Additional functions and utility code can be added here if needed]
