# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function retrieves data from a DynamoDB table representing game details and returns
#              the information in a list format.

import json
import boto3

# Create a DynamoDB resource and specify the table to interact with
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('gameCreationDb')

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    try:
        # Perform a scan operation on the DynamoDB table to retrieve all game records
        response = table.scan()
        games = response.get('Items', [])
        game_list = []
        
        # Loop through each game record and extract relevant information
        for game in games:
            game_id = str(game['game_id'])
            category = game['category']
            difficulty_level = game['difficulty_level']
            time_frame_minutes = str(game['time_frame_minutes'])
            questions = game['questions']
            
            # Add game details to the list
            game_details = {
                'game_id': game_id,
                'category': category,
                'difficulty_level': difficulty_level,
                'time_frame_minutes': time_frame_minutes,
                'questions': questions
            }
            game_list.append(game_details)

        # Prepare and return a successful response with status code 200
        return {
            'statusCode': 200,
             'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps(game_list)  # Convert the game list to a JSON string
        }
    except Exception as e:
        # If there's an exception, return an error response with status code 500
        return {
            'statusCode': 500,
             'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps({'error': str(e)})  # Convert the error message to a JSON string
        }

# [Additional functions and utility code can be added here if needed]
