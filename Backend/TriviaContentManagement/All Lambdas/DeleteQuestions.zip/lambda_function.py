# Author: Krishna Modi
# Date Created: 23 July 2023
# Date Updated: 5 August 2023
# Description: This Lambda function receives a question ID as input, deletes the corresponding question from
#              the DynamoDB table, and returns a response indicating the success of the deletion.

import json
import boto3

# Create a DynamoDB resource and specify the table to interact with
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('questionsdb')

# Lambda handler function - Entry point for AWS Lambda
def lambda_handler(event, context):
    try:
        # Extract the request body as a JSON string from the event
        body_json = event.get('body')
        event = json.loads(body_json)

        # Extract the question ID from the event
        question_id = event['question_id']

        # Delete the question with the specified ID from the DynamoDB table using the 'delete_item' method
        table.delete_item(Key={'question_id': question_id})

        # Prepare and return a successful response with status code 200
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps({'message': 'Question deleted successfully.'})
        }
    except Exception as e:
        # If there's an exception, return an error response with status code 500
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
                'Access-Control-Allow-Origin': '*',
                'Allow': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT'
            },
            'body': json.dumps({'error': str(e)})  # Convert the error message to a JSON string
        }

# [Additional functions and utility code can be added here if needed]
